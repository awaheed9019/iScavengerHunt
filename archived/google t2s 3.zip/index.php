<?php 
if(isset($_POST['submit']))
{
    include 'PHP_Text2Speech.class.php'; 
    $t2s = new PHP_Text2Speech; 
    $content = '<audio controls="controls" autoplay="autoplay"> 
                <source src="'.$t2s->speak($_POST['word']).'" type="audio/mp3" /> 
                </audio>
                <form action="" method="post">
                <table><tr>
<td colspan="2"><input type="text" value="'.$_POST['word'].'" name="word" style="width: 335px;" /></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="Play" name="submit" /></td>
</tr>
</table>
                
                </form>';
}                               
else
{
   $content = '<form action="" method="post">
                <table><tr>
<td colspan="2"><input type="text" value="Hello world" name="word" style="width: 335px;" /></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="Play" name="submit" /></td>
</tr>
</table>
                
                </form>';
}                                                  

$title = "How to convert text to voice with Google";
$heading = "How to convert text to voice with Google PHP example.";
include('html.inc');

?> 